import os, numpy as np
from torchvision import datasets,transforms
transform=transforms.ToTensor()
test=datasets.MNIST("./data",train=False,download=True,transform=transform)
os.makedirs("calib",exist_ok=True)
for i in range(50):
    x,_=test[i]
    np.save(f"calib/{i}.npy",x.numpy())
print("Calibration files created.")
