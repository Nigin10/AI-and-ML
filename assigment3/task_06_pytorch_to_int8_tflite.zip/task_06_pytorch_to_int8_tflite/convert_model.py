import os, sys, logging, numpy as np, torch, onnx
import tensorflow as tf
from model_definition import SimpleCNN

logging.basicConfig(filename="conversion_log.txt",level=logging.INFO)

if not os.path.exists("model.pth"):
    raise FileNotFoundError("model.pth not found")

model=SimpleCNN()
model.load_state_dict(torch.load("model.pth",map_location="cpu"))
model.eval()

if not os.path.isdir("calib"):
    raise FileNotFoundError("calib folder missing")
files=sorted([f for f in os.listdir("calib") if f.endswith(".npy")])
if not files:
    raise RuntimeError("No calibration files")

def representative_dataset():
    for f in files:
        arr=np.load(os.path.join("calib",f))
        if arr.shape!=(1,28,28):
            raise ValueError(f"Bad shape {arr.shape}")
        if not np.isfinite(arr).all():
            raise ValueError("NaN/Inf detected")
        yield [arr[np.newaxis,...].astype(np.float32)]

dummy=torch.randn(1,1,28,28)
torch.onnx.export(model,dummy,"model.onnx",
                  input_names=["input"],output_names=["output"],
                  opset_version=13)
onnx.checker.check_model("model.onnx")
logging.info("ONNX export successful")

try:
    from onnx_tf.backend import prepare
    saved=prepare(onnx.load("model.onnx"))
    saved.export_graph("saved_model")
except Exception as e:
    raise RuntimeError(f"ONNX->TF failed: {e}")

converter=tf.lite.TFLiteConverter.from_saved_model("saved_model")
converter.optimizations=[tf.lite.Optimize.DEFAULT]
converter.representative_dataset=representative_dataset
converter.target_spec.supported_ops=[tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
converter.inference_input_type=tf.int8
converter.inference_output_type=tf.int8
tflite_model=converter.convert()

with open("model_int8.tflite","wb") as f:
    f.write(tflite_model)

interpreter=tf.lite.Interpreter(model_path="model_int8.tflite")
interpreter.allocate_tensors()
inp=interpreter.get_input_details()[0]
out=interpreter.get_output_details()[0]
print("Input dtype:",inp["dtype"])
print("Output dtype:",out["dtype"])
print("Input quant:",inp["quantization"])
print("Output quant:",out["quantization"])
print("Model size (KiB):",os.path.getsize("model_int8.tflite")/1024)

x=np.zeros(inp["shape"],dtype=np.int8)
interpreter.set_tensor(inp["index"],x)
interpreter.invoke()
print("Inference output:",interpreter.get_tensor(out["index"]))
logging.info("Conversion completed")
