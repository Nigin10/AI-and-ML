import torch
from torch import nn,optim
from torch.utils.data import DataLoader
from torchvision import datasets,transforms
from model_definition import SimpleCNN

transform=transforms.ToTensor()
train=datasets.MNIST("./data",train=True,download=True,transform=transform)
loader=DataLoader(train,batch_size=64,shuffle=True)

model=SimpleCNN()
criterion=nn.CrossEntropyLoss()
opt=optim.Adam(model.parameters(),lr=1e-3)

model.train()
for epoch in range(2):
    for x,y in loader:
        opt.zero_grad()
        loss=criterion(model(x),y)
        loss.backward()
        opt.step()
    print("Epoch",epoch+1,"Loss",loss.item())

torch.save(model.state_dict(),"model.pth")
print("Saved model.pth")
