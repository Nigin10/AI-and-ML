# Task 06

Run:

1. pip install -r requirements.txt
2. python train_model.py
3. python generate_calibration.py
4. python convert_model.py

Outputs:
- model.pth
- calib/
- model.onnx
- saved_model/
- model_int8.tflite
- conversion_log.txt
